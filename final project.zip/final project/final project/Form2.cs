﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace final_project
{
    public partial class Form2 : Form

    {

        double[] nums = new double[3];

        string textfile = "palestine.txt";// The name of the  text file here 
        double weightKg, heightM;
        public Form2(string tr)
        {
            InitializeComponent();
            textBox12.Text = tr;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // check if the input values textbox1 , textbox2 and textbox 3 with the sorted values
            {
                if (double.TryParse(textBox6.Text, out nums[0]) &&
        double.TryParse(textBox7.Text, out nums[1]) &&
        double.TryParse(textBox8.Text, out nums[2]))

                {
                    // sort the inputs from the smallest to the biggest
                    Array.Sort(nums);
                    // calculate the sum of the sorted numbers 
                    double sum = nums[0] + nums[1] + nums[2];
                    // display sum in textbox4
                    textBox9.Text = sum.ToString();
                    textBox9.ForeColor = (sum > 200) ? Color.DarkViolet : SystemColors.ControlText;

                    textBox6.Text = nums[0].ToString();
                    textBox7.Text = nums[1].ToString();
                    textBox8.Text = nums[2].ToString();
                    {


                    }
                }
            }



        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

            textBox6.BackColor = Color.BlueViolet;// change the backgroung color to blue violet
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

            textBox8.BackColor = Color.Orange;// change the backgroung color to orange
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

            textBox8.BackColor = Color.YellowGreen;// change the backgroung color to yellow green
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(textfile))
                {
                    string fileContent = File.ReadAllText(textfile);
                    MessageBox.Show(fileContent, "file content");
                }


                else
                {

                    MessageBox.Show("File does not exist .", "File Read");

                }

            }
            catch (Exception ex)

            {
                MessageBox.Show("an error occured:" + ex.Message, "error");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            // Append text from textbox 11 to the end of the "HEALTHY.txt" file.

            try
            {
                File.AppendAllText(textfile, textBox11.Text + Environment.NewLine);
                MessageBox.Show("text appended to the file.", "file append");
            }
            catch (Exception ex)
            {
                MessageBox.Show("an error occured:" + ex.Message, "error");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            // Allow the user to select a text file , read its content and displayit im textbox11 and a message box 
            openFileDialog1 = new OpenFileDialog();// declare openFileDialog1 locally.
            openFileDialog1.Title = "choose a file for reading";
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files(*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.ShowDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var filepath = openFileDialog1.FileName;

                using (StreamReader reader = new StreamReader(filepath))
                {
                    var filecontent = reader.ReadToEnd();
                    textBox11.Text = (filecontent);
                    //Display the files content in a message box
                    MessageBox.Show(filecontent, "file content");
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // event handler for when an item is selected in listbox1
            if (listBox1.SelectedIndex == 0)
                MessageBox.Show("yougurt100,Eggs78,Grained bread75, Avocado240");
            else if (listBox1.SelectedIndex == 1)
                MessageBox.Show("Tuna 203, Mini sweet Peppers35, Hummus130, Apples95 ");
            else
            {
                MessageBox.Show(" poultry296, salmon 824,potatoes164,brown rice216");
            }




        }



        private void button6_Click(object sender, EventArgs e)
        {
            // event handler when button 6 is clicked
            // set the text of textbox10 to a health message
            textBox10.Text = " Eat healthy , sleep well, excersice  for a better life";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // create andd show form1 with text from textbox12
            Form1 f1 = new Form1(textBox12.Text);
            f1.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // Set a tooltip for the TextBox
            toolTip1.SetToolTip(textBox3, "BMI IN WEEK 3.");

            toolTip1.SetToolTip(textBox4, "BMI IN WEEK 4.");

            toolTip1.SetToolTip(textBox10, " A fact.");

            toolTip1.SetToolTip(textBox9, "amount of calories a day.");


            toolTip1.SetToolTip(textBox6, "Amount of calories taken in breakfast.");


            toolTip1.SetToolTip(textBox7, "amount of calroies taken in lunch");

            toolTip1.SetToolTip(textBox8,"amount of calories taken in dinner.");


            toolTip1.SetToolTip(textBox1, "BMI IN WEEK 1");


            toolTip1.SetToolTip(textBox2, "BMI IN WEEK2.");

            toolTip1.SetToolTip(textBox5, "average of bmi in a month.");
            toolTip1.SetToolTip(textBox11, "write in a file .");

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal[] nums = new decimal[4];
            decimal sum = 0;
            // check if the input values in textbox5 and textbox and textbox 7 and textbox 8 can be parsed as decimals 
            if (decimal.TryParse(textBox1.Text, out nums[0]) &&
              decimal.TryParse(textBox2.Text, out nums[1]) &&
               decimal.TryParse(textBox3.Text, out nums[2]) &&
                  decimal.TryParse(textBox4.Text, out nums[3]))
            {
                Array.Sort(nums);


                // calculate the sum of the inputs values 
                for (int i = 0; i < nums.Length; i++)
                {
                    sum += nums[i];
                }

                decimal average = sum / 4;



                textBox5.Text = average.ToString("F2");
                string filepath = "s ";
                using (StreamWriter writer = new StreamWriter(filepath))
                {
                    writer.WriteLine("Average : " + average.ToString("F2"));
                }

                foreach (Control x in this.Controls)

                    if (x is Label)
                    {
                        // set the background color of the label to darkred

                        x.BackColor = Color.DarkRed;
                        // set the text color (forecolor) of the label to khai
                        x.ForeColor = Color.Khaki;

                        textBox1.BackColor = Color.PeachPuff;// change the backgroung color to PEACH PUFF
                        textBox2.BackColor = Color.DarkGreen;// change the backgroung color to DARK green
                        textBox3.BackColor = Color.BlueViolet;// change the backgroung color to BLUE VIOLET
                        textBox4.BackColor = Color.Red;// change the backgroung color to yellow RED
                    }

            }

        }


    }
}    

                            
                            
                        
                    
            
        
    

